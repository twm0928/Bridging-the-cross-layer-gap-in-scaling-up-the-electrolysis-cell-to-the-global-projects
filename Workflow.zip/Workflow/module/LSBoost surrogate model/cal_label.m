delta_t = 0.25; % 系统总电功率指令的时间颗粒度（单位：时）
price_ele = 0.2; % 电价（单位：元/kWh）
price_H2 = 2.5; % 氢价（单位：元/Nm3）
num=[4 4 4 2 2 1];

f=4;

obj=zeros(6,1080);
H=[];
P=[];
for t=1:6
    filename = sprintf('results_topology_%d.mat', t);
    data = load(filename);  % 加载的数据保存到data变量
    for i=1:1080
        if size(data.result{i,4})>1
            H(t,i)=sum(sum(data.result{i,4}(:, num(t)+1:num(t)+num(t))))*delta_t*60*60*2/1e6; % t
            P(t,i)=sum(sum(data.result{i,4}(:, 1:num(t))))*delta_t; % MWh
            obj(t,i)=H(t,i)*11.2*1000*price_H2-P(t,i)*1000*price_ele;
        end
    end
end

capex=[2800 2738 2688 2202 2152 1938]*1e4*2;
opex=0.03;
lifetime=15;
r=0.06;
daily_capex=capex*(opex+1/(1/r+1/(1+r)^lifetime))/365;

[Q, label_H] = max(H);

[opex, label_O] = max(obj);

obj=obj-daily_capex';
[total, label_total] = max(obj);




