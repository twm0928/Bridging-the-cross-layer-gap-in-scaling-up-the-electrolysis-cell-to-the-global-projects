N = readmatrix('topology', 'Sheet', 'Sheet2', 'Range', 'B2:G8');

I=cell(6,1080);
T=cell(6,1080);
S=cell(6,1080);
for t=1:6
    N_st = N(1,t); % 电解槽台数
    N_sp = N(2,t); % 气液分离框架的数量
    filename = sprintf('results_topology_%d.mat', t);
    data = load(filename);  % 加载的数据保存到data变量
    for i=1:1080
        if size(data.result{i,4})>1
            S{t,i}=data.result{i,4}(:, 2*N_st+1:3*N_st); % status
            I{t,i}=data.result{i,4}(:, 3*N_st+1:4*N_st); % A
            T{t,i}=data.result{i,4}(:, 6*N_st+2*N_sp+1:7*N_st+2*N_sp); % oC
        end
        if ~isnan(T{t,i})==1
            aveT{t,i}=mean(T{t,i});
            dT=diff(T{t,i});
            deltaT{t,i}=mean(abs(dT));
        end
        if ~isnan(I{t,i})==1
            aveI{t,i}=mean(I{t,i});
            dI=diff(I{t,i});
            deltaI{t,i}=mean(abs(dI));
        end
        if ~isnan(S{t,i})==1
            aveS{t,i}=mean(S{t,i});
            dS=diff(S{t,i});
            deltaS{t,i}=mean(abs(dS));
        end
    end
end

Ist=cell(4,1);
Tst=cell(4,1);
deltaIst=cell(4,1);
deltaTst=cell(4,1);

for s=1:4
    for t=1:3
        for i=idx_gen
            Ist{s,1}(i,t)=aveI{t,i}(s);
            Tst{s,1}(i,t)=aveT{t,i}(s);
            deltaIst{s,1}(i,t)=deltaI{t,i}(s);
            deltaTst{s,1}(i,t)=deltaT{t,i}(s);
            deviaIst(i,t)=mean(max(I{t,i}, [], 2) - min(I{t,i}, [], 2));
            deviaTst(i,t)=mean(max(T{t,i}, [], 2) - min(T{t,i}, [], 2));
        end
    end
end






