% 假设已有数据：
% P_command: 1080×96 的波形数据
% label: 1080×1 的拓扑标签（取值 1~6）
% 计算不同场景的数学特征、最优拓扑编号、能效，输出features(250, 5), data_gen(mean, low, ramping, high, period, label, E, H, yita)...
% yita(6,240), yita_ave(1,240), yita_gap(1,240)

load('P_command.mat');  % 尺寸应为 [num_samples × num_timesteps]
cal_label;
% cal_fault_label;
freq=[ones(1,730) 2*ones(1,20) 4*ones(1,20) 16*ones(1,20) 48*ones(1,20) 96*ones(1,20)...
    2*ones(1,50) 4*ones(1,50) 16*ones(1,50) 2*ones(1,50) 96*ones(1,50)];

idx_gen=[732:2:770 771:1:830 831:5:876 881:5:926 883:5:928 931:5:976 932:5:977 933:5:978 934:5:979 981:5:1026 982:5:1027 983:5:1028 984:5:1029 1031:1080];
% idx_gen=[732:2:770 771:1:830];

label=[];
Q=[];
E=[];

window=idx_gen; % 1:1:1080; %365/730/830/1080
% window=1:1:1080; %365/730/830/1080
label=label_H(window)'; % label_H/O/total
cols = (1:length(label))';  
H=H(:,window);
Q=H(sub2ind(size(H), label, cols));
P=P(:,window);
E=P(sub2ind(size(P), label, cols));
yita=H*33.33./P;
yita(find(isnan(yita)==1)) = 0;

yita_gap=max(yita)-min(yita);
yita_ave=sum(yita)/5;

% label=flag(4,window); % label_H/PH/total

%% 计算features
% 输入：P_command (1080,96)，label (1080,1)
num_samples = size(P_command,1);
num_points = size(P_command,2);
features = zeros(num_samples, 5); % 5个特征

for i = window-window(1)+1
    x = P_command(i+window(1)-1, :);

    % 特征1：mean_val（平均功率,MW）归一化
    features(i,1) = mean(x)/20;

    % 特征2：low_hold_duration（低负荷最大连续时长,15min）归一化
    threshold = 0.2 * 20;
    below_thresh = x < threshold;
    max_len = 0; current_len = 0;
    for j = 1:num_points
        if below_thresh(j)
            current_len = current_len + 1;
            max_len = max(max_len, current_len);
        else
            current_len = 0;
        end
    end
    features(i,2) = max_len/96;

    % 特征3：freq_delta（相邻差值平均,%/15min）
    dx = diff(x);
    features(i,3) = mean(abs(dx))/20;

    % 特征4：fft_high_ratio（周期≤1小时的高频能量占比）
    X = abs(fft(x));
    X = X(2:floor(num_points/2));  % 去掉直流项和对称部分
    fs = 4;                        % 每小时4个采样点
    freq_resolution = fs / num_points;
    freqs = (1:length(X)) * freq_resolution;  % 各频率点（单位：次/小时）

    high_freq_idx = freqs >= 1;  % 高频频率索引（周期≤1小时）
    features(i,4) = sum(X(high_freq_idx)) / sum(X);

    features(i,5)=freq(i+window(1)-1);

end

features(find(isnan(features)==1)) = 0;

features_gen=features(window-window(1)+1,:);
features=features_gen;

data_gen=[features_gen label Q E Q*33.33./E yita_gap']; % t,MWh
data_gen(find(isnan(data_gen)==1)) = 0;

% 按拓扑分类统计
num_topo = 6;
group_mean = zeros(num_topo, 5);
group_count = zeros(num_topo, 1);

for t = 1:num_topo
    idx = (label == t);
    group_count(t) = sum(idx);
    if group_count(t)>1
        group_mean(t, :) = mean(features(idx, :));
    elseif group_count(t)==1
        group_mean(t, :) = features(idx, :);
    end
end

%% IT运行结果
cal_IT;
Ist_gen=zeros(length(idx_gen),3);
I4st_gen=cell(3,1);
T4st_gen=cell(3,1);
Tst_gen=zeros(length(idx_gen),3);
deltaIst_gen=zeros(length(idx_gen),3);
deltaTst_gen=zeros(length(idx_gen),3);
deviaIst_gen=zeros(length(idx_gen),3);
deviaTst_gen=zeros(length(idx_gen),3);
for t=1:3
    for s=1:4
        Ist_test=Ist{s,1}(idx_gen,t);
        Ist_gen(:,t)=Ist_gen(:,t)+Ist_test;
        I4st_gen{t}=[I4st_gen{t} Ist_test];
        Tst_test=Tst{s,1}(idx_gen,t);
        Tst_gen(:,t)=Tst_gen(:,t)+Tst_test;
        T4st_gen{t}=[T4st_gen{t} Tst_test];
        deltaIst_test=deltaIst{s,1}(idx_gen,t);
        deltaIst_gen(:,t)=deltaIst_gen(:,t)+deltaIst_test;
        deltaTst_test=deltaTst{s,1}(idx_gen,t);
        deltaTst_gen(:,t)=deltaTst_gen(:,t)+deltaTst_test;     
    end
end
Ist_gen=Ist_gen/4;
Tst_gen=Tst_gen/4;
deltaIst_gen=deltaIst_gen/4;
deltaTst_gen=deltaTst_gen/4;
deviaIst_gen=deviaIst(idx_gen,:);
deviaTst_gen=deviaTst(idx_gen,:);

%% 绘制 features-最优拓扑 分区图（线性ECOC-SVM；可选：置信度/支集遮罩）
% 依赖：features (N×≥4)，yita (6×N)
assert(size(features,2) >= 4, 'features需至少4列');

% —— 选择用于分区可视化的样本子集（与你原逻辑一致，可调）
idx_ramp = features(:,3) <= 0.2;     % Ramping 约束
idx_high = features(:,4) <= 0.4;     % 高频比 约束
sel = idx_ramp & idx_high;

Xall   = features(sel,:);            % N_sel × 4
etaSel = yita(:, sel)';              % N_sel × 6

% —— 只比较的候选拓扑（默认 1~3；若要 1~6，把 cand 改为 1:6 并补颜色）
cand = 1:3;

% —— 每个样本的“最优拓扑”标签（真值，用于训练/上色/评估）
[~, pos] = max(etaSel(:, cand), [], 2);   % 在 cand 内找最大效率位置
y_all    = cand(pos);                      % 真实类标签 ∈ cand

% —— 选择作图的两个特征维度（x–y 轴）
x_col = 1;   % 1=Mean, 2=Low, 3=Ramping, 4=High
y_col = 3;   % 例：Mean vs High
labels = {'Mean Power (per unit)','Low-load Duration (per 15 minutes)', ...
          'Average Absolute Ramping','High-frequency Ratio'};
x_name = labels{x_col};  y_name = labels{y_col};
X2 = Xall(:, [x_col, y_col]);             % N_sel × 2

% —— 若该切片只有一个最优类，则只画散点并提醒
if numel(unique(y_all)) < 2
    figure('Color','w'); hold on; box on; grid on;
    scatter(X2(:,1), X2(:,2), 18, 'filled', 'MarkerEdgeColor','k', ...
        'MarkerFaceAlpha',0.9, 'MarkerEdgeAlpha',0.3);
    xlabel(x_name); ylabel(y_name);
    title('该切片仅含一个最优类，无法形成边界（请放宽筛选或更换轴）');
    return;
end
legend('Location','best','Box','off');

% ===== 颜色（确保与拓扑编号一一对应）=====
hex2rgb = @(h) [hex2dec(h(2:3)) hex2dec(h(4:5)) hex2dec(h(6:7))]/255;
% 只给 1~3；如需到6，自行补足后三行颜色
topo_colors = [
    hex2rgb('#F3A332');  % Topo 1
    hex2rgb('#018A67');  % Topo 2
    hex2rgb('#1868B2')   % Topo 3
];
assert(numel(cand) <= size(topo_colors,1), 'cand 超出配色范围，请补充颜色。');

% ===== 统一编码：把真实类 y_all ∈ cand 映射到 1..K，确保配色不乱 =====
[tf, y_enc] = ismember(y_all, cand);     % y_enc ∈ {1..K}
assert(all(tf), 'y_all 存在不在 cand 内的标签，请检查 cand 设置。');
K = numel(cand);

% ===== 训练线性多类SVM (ECOC one-vs-one)（用编码标签）=====
% 线性（清晰直线）
templ = templateSVM('KernelFunction','linear','Standardize',true);

% 多项式二/三阶（平滑弯曲）
% templ = templateSVM('KernelFunction','polynomial','PolynomialOrder',3,...
%                     'KernelScale','auto','Standardize',true);

% RBF/高斯（灵活，记得控平滑度）
% —— 第一步：用 auto 拿一个“基准尺度” ks0
templ_auto = templateSVM('KernelFunction','rbf','KernelScale','auto','Standardize',true);
M0 = fitcecoc(X2, y_enc, 'Learners', templ_auto, ...
              'Coding','onevsone','ClassNames',1:K,'Prior','uniform');

% 从各个二分类器里读出 auto 的尺度，取中位数做代表
sc = nan(numel(M0.BinaryLearners),1);
for l = 1:numel(M0.BinaryLearners)
    bl = M0.BinaryLearners{l};
    try
        sc(l) = bl.KernelParameters.Scale;   % 新版常用
    catch
        try
            sc(l) = bl.ModelParameters.KernelScale;  % 备用路径（老版本）
        catch
            sc(l) = NaN;
        end
    end
end
ks0 = median(sc(~isnan(sc)));

% —— 第二步：把 KernelScale 设为 “auto×0.5”，然后重训最终模型
ks = ks0 * 4;   % ← 你要的 0.5 倍
% templ = templateSVM('KernelFunction','rbf','KernelScale', ks, 'Standardize', true);

Mdl = fitcecoc(X2, y_enc, 'Learners', templ, ...
               'Coding','onevsone','ClassNames',1:K,'Prior','uniform');

% —— 概率/置信度（可用于遮罩；fitPosterior 如不可用会回退）
try
    MdlP = fitPosterior(Mdl, X2, y_enc);   % Platt 校准
catch
    MdlP = Mdl;                             % 老版本无 fitPosterior
end

% ===== 网格预测（得到 1..K 的编码标签与后验分数）=====
nx = 400; ny = 320;
xg = linspace(min(X2(:,1)), max(X2(:,1)), nx);
yg = linspace(min(X2(:,2)), max(X2(:,2)), ny);
[Xg, Yg] = meshgrid(xg, yg);
Xg2 = [Xg(:), Yg(:)];

[clabel_enc, score] = predict(MdlP, Xg2);     % clabel_enc ∈ {1..K}
if any(score(:) < 0)                          % 保险：分数→伪概率
    smax = exp(score - max(score,[],2));
    score = smax ./ sum(smax,2);
end
grid_label = reshape(clabel_enc, ny, nx);     % 网格上的编码标签
conf = max(score,[],2);                       % 置信度（最大后验）
conf_map = reshape(conf, ny, nx);

% ===== （可选）支集/置信度遮罩，默认关闭。开启请置 true =====
DO_MASK = false;                 % ← 你开启遮罩
AlphaFill = ones(ny, nx) * 0.1;   % 默认：全域轻度填色
if DO_MASK
    % —— Silverman 逐维带宽
    [nN, dN] = size(X2);                   % dN=2
    sig = std(X2, 0, 1);
    mad_rob = mad(X2, 1, 1)/0.6745;
    sig = max(sig, max(1e-6, mad_rob));
    h = (4/(dN+2))^(1/(dN+4)) * nN^(-1/(dN+4)) .* sig;

    % —— 密度估计
    dens_grid = mvksdensity(X2, Xg2, 'Bandwidth', h);
    dens_tr   = mvksdensity(X2, X2,  'Bandwidth', h);

    % —— 置信度（若 score 不是概率，softmax 一下）
    [clabel_enc, score] = predict(MdlP, Xg2);
    if any(score(:) < 0)
        smax  = exp(score - max(score,[],2));
        score = smax ./ sum(smax,2);
    end
    conf = max(score,[],2);                     % 最大后验当置信
    conf_map = reshape(conf, ny, nx);

    % ===== 1) 先定密度阈值 tau（自适应放宽到 P5/P2）=====
    tau  = quantile(dens_tr, 0.10);
    cov_d = mean(dens_grid >= tau);
    if cov_d < 0.30, tau = quantile(dens_tr, 0.05); cov_d = mean(dens_grid >= tau); end
    if cov_d < 0.15, tau = quantile(dens_tr, 0.02); cov_d = mean(dens_grid >= tau); end

    % ===== 2) 再定置信阈值 m0（基于致密区的置信分布）=====
    conf_dense = conf(dens_grid >= tau);
    if isempty(conf_dense), m0 = 0.50; else, m0 = quantile(conf_dense, 0.30); end
    m0 = max(0.45, min(0.65, m0));              % 夹紧在 [0.45,0.65]

    % ===== 3) 组合遮罩；若覆盖仍过低，降级为“密度-only” =====
    mask = (dens_grid >= tau) & (conf >= m0);
    coverage = mean(mask);
    if coverage < 0.05
        mask = (dens_grid >= tau);
        coverage = mean(mask);
    end

    AlphaFill = reshape(mask, ny, nx) * 0.25;   % 仅在有效域着色
    fprintf('Coverage=%.1f%%  tau=%.3g  m0=%.2f  (dens-only fallback=%d)\n', ...
            100*coverage, tau, m0, coverage<0.05);
end

% ===== 构造 RGB 底图（颜色严格按 1..K 行匹配）=====
C = zeros(ny, nx, 3);
for k = 1:K
    mm = (grid_label == k);
    C(:,:,1) = C(:,:,1) + mm * topo_colors(k,1);
    C(:,:,2) = C(:,:,2) + mm * topo_colors(k,2);
    C(:,:,3) = C(:,:,3) + mm * topo_colors(k,3);
end

% ===== 画图：彩色底 + 清晰黑色边界 + 样本点 =====
figure('Color','w'); hold on;
image(xg, yg, C, 'AlphaData', AlphaFill); 
set(gca,'YDir','normal'); axis tight; box on; grid on;

contour(Xg, Yg, double(grid_label), 'k', 'LineWidth', 1.2, 'HandleVisibility','off');

for k = 1:K
    ii = (y_enc == k);
    if any(ii)
        scatter(X2(ii,1), X2(ii,2), 18, ...
            'MarkerFaceColor', topo_colors(k,:), ...
            'MarkerEdgeColor', 'k', ...
            'MarkerFaceAlpha', 0.9, 'MarkerEdgeAlpha', 0.35);
    end
end

xlabel(x_name); ylabel(y_name);
% title(sprintf('Decision Regions (Linear ECOC-SVM): %s vs %s', x_name, y_name));

% for k = 1:K
%     plot(nan, nan, 'o', 'MarkerFaceColor', topo_colors(k,:), 'MarkerEdgeColor','k', ...
%         'MarkerSize', 8, 'DisplayName', sprintf('Topology %d', cand(k)));
% end
legend('Location','best','Box','off');

% —— 先把真实类 y_all 映射到 1..K，确保颜色/类别一一对应
cand = 1:3;                                 % 需要比较的拓扑集合（如 1:6 也可）
[tf, y_enc] = ismember(y_all, cand);        % 1..K 编码
assert(all(tf), 'y_all 中存在不在 cand 里的标签');

K = numel(cand);
etaCand = etaSel(:, cand);                  % N_sel × K（每列对应 cand 中的一个拓扑）

%% ===== 多种核对比遴选/构造候选核列表（不用 setfield）=====
cands = struct('name',{},'templ',{},'isRBF',{},'mult',{});

% linear
cands(end+1) = struct( ...
    'name','linear', ...
    'templ', templateSVM('KernelFunction','linear','Standardize',true), ...
    'isRBF', false, 'mult', NaN);

% polynomial d=2,3
cands(end+1) = struct( ...
    'name','poly2', ...
    'templ', templateSVM('KernelFunction','polynomial','PolynomialOrder',2, ...
                         'KernelScale','auto','Standardize',true), ...
    'isRBF', false, 'mult', NaN);
cands(end+1) = struct( ...
    'name','poly3', ...
    'templ', templateSVM('KernelFunction','polynomial','PolynomialOrder',3, ...
                         'KernelScale','auto','Standardize',true), ...
    'isRBF', false, 'mult', NaN);

% rbf: auto + 若干倍率（更平滑：倍率>1）
cands(end+1) = struct( ...
    'name','rbf_auto', ...
    'templ', templateSVM('KernelFunction','rbf','KernelScale','auto','Standardize',true), ...
    'isRBF', true, 'mult', 1);

for m = [4]
    cands(end+1) = struct( ...
        'name', sprintf('rbf_auto_x%.1f', m), ...
        'templ', templateSVM('KernelFunction','rbf','KernelScale','auto','Standardize',true), ...
        'isRBF', true, 'mult', m);
end

% —— 预取一个“auto”的 RBF 尺度（用二分类器中位数），供倍率法复用
rbfScale0 = NaN;
try
    M0 = fitcecoc(X2, y_enc, 'Learners', templateSVM('KernelFunction','rbf','KernelScale','auto','Standardize',true), ...
                  'Coding','onevsone','ClassNames',1:K,'Prior','uniform');
    try
        sc = arrayfun(@(bl) bl.KernelParameters.Scale, [M0.BinaryLearners{:}]);
        rbfScale0 = median(sc);
    catch
        % 某些版本用不同访问方式，兜底取第一位
        rbfScale0 = M0.BinaryLearners{1}.KernelParameters.Scale;
    end
catch
    % 失败就保持 NaN，后面倍率候选会自动跳过“固定尺度重训”
end

% ===== 逐候选评估（5折 Acc + Mean Regret），选最优 =====
results = struct('name',{},'acc',{},'meanRegret',{},'mdl',{});
for i = 1:numel(cands)
    templ = cands(i).templ;

    % 先按当前模板训练
    M = fitcecoc(X2, y_enc, 'Learners', templ, 'Coding','onevsone', ...
                 'ClassNames',1:K, 'Prior','uniform');

    % 若是 rbf_auto×mult，且拿到了 rbfScale0，则改成“固定尺度=rbfScale0*mult”再重训一次
    if cands(i).isRBF && isfinite(cands(i).mult) && ~isnan(rbfScale0) && cands(i).mult ~= 1
        ks = rbfScale0 * cands(i).mult;
        templFix = templateSVM('KernelFunction','rbf','KernelScale',ks,'Standardize',true);
        M = fitcecoc(X2, y_enc, 'Learners', templFix, 'Coding','onevsone', ...
                     'ClassNames',1:K, 'Prior','uniform');
    end

    % 5折评估：准确率 + 平均遗憾（效率损失）
    cvM   = crossval(M,'KFold',5);
    cpred = kfoldPredict(cvM);                % 1..K
    linInd  = sub2ind(size(etaCand), (1:size(etaCand,1))', cpred);
    eta_pred = etaCand(linInd);
    eta_best = max(etaCand,[],2);
    regret   = eta_best - eta_pred;
    acc      = 1 - kfoldLoss(cvM);

    results(end+1) = struct('name',cands(i).name, 'acc',acc, ...
                            'meanRegret',mean(regret), 'mdl',M); %#ok<AGROW>
end

% —— 以 Mean Regret 作为主指标选最优；若与 linear 差 < 0.002pp，则偏向 linear
[~, idxMin] = min([results.meanRegret]);
winner = results(idxMin);

linIdx = find(strcmp({results.name},'linear'),1);
if ~isempty(linIdx)
    if results(linIdx).meanRegret <= winner.meanRegret + 0.002
        winner = results(linIdx);
    end
end

fprintf('核选择 → %s | Acc=%.3f  MeanRegret=%.4f (pp)\n', ...
        winner.name, winner.acc, winner.meanRegret);

% 最终用于作图/预测的模型：
Mdl = winner.mdl;



%% 绘制能效-mean曲线
% 假定已有：
% features: N×4 (1=mean, 2=low, 3=ramping, 4=high)
% yita: 6×N    (6种拓扑的效率)

% 颜色（按需求三色）
hex2rgb = @(h) [hex2dec(h(2:3)) hex2dec(h(4:5)) hex2dec(h(6:7))]/255;
groupColors = [ ...
    hex2rgb('#F3A332');  % 组1: Topo 1-3
    hex2rgb('#018A67');  % 组2: Topo 4-5
    hex2rgb('#1868B2')]; % 组3: Topo 6

% 线型（组内区分）
ls_13 = {'-','--',':'};   % Topo 1,2,3
ls_45 = {'-','--'};       % Topo 4,5
ls_6  = {'-'};            % Topo 6

% mean分箱
mean_bins = linspace(min(features(:,1)), max(features(:,1)), 10);  % 可调整分箱数

figure; hold on;

for t = 1:6
    % 映射颜色 & 线型
    if t <= 3
        c = groupColors(1,:); ls = ls_13{t};
    elseif t <= 5
        c = groupColors(2,:); ls = ls_45{t-3};
    else
        c = groupColors(3,:); ls = ls_6{1};
    end

    mean_centers = zeros(1, length(mean_bins)-1);
    eff_mean = nan(1, length(mean_bins)-1);
    eff_min  = nan(1, length(mean_bins)-1);
    eff_max  = nan(1, length(mean_bins)-1);
    eff_std  = nan(1, length(mean_bins)-1);

    for m = 1:length(mean_bins)-1
        idx = features(:,1) >= mean_bins(m) & features(:,1) < mean_bins(m+1) ...
            & features(:,3) >= 0 & features(:,3) <= 0.2;  % ramping筛选
        vals = yita(t, idx);

        mean_centers(m) = mean([mean_bins(m), mean_bins(m+1)]);
        vals = vals(isfinite(vals));  % 去掉NaN/Inf
        if ~isempty(vals)
            eff_mean(m) = mean(vals);
            eff_min(m)  = min(vals);
            eff_max(m)  = max(vals);
            eff_std(m)  = std(vals);
        end
    end

    % 阴影带（上下限），用组颜色 + 统一透明度
    fill([mean_centers, fliplr(mean_centers)], ...
         [eff_min,      fliplr(eff_max)], ...
         c, 'FaceAlpha', 0.15, 'EdgeColor', 'none', 'HandleVisibility','off');

    % 也可改成均值±std带：
    % fill([mean_centers, fliplr(mean_centers)], ...
    %      [eff_mean-eff_std, fliplr(eff_mean+eff_std)], ...
    %      c, 'FaceAlpha', 0.15, 'EdgeColor', 'none');

    % 均值主曲线（用组色 + 线型区分）
    plot(mean_centers, eff_mean, ls, ...
        'Color', c, 'LineWidth', 2, ...
        'DisplayName', sprintf('Topolopy %d', t));
end

xlabel('Mean Power (per unit)');
ylabel('Module Efficiency');
grid off;
box on;
legend('Location','best', 'Box', 'off');
hold off;