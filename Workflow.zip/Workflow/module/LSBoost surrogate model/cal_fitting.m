% 假设已加载变量：
% features: N×5，列顺序为 [mean, ramping, low-load-duration, fft, period]
% efficiency: N×1，比如单位电耗或氢电比等
% 回归不同拓扑能效-场景特征模型

cal_index;

%%
% for run =1:10 % 2指标最好
for t=2
    % Step 1: 提取4特征
    X = features(:, 1:4);  % mean, ramping, low-load-duration
    y = yita(t,:)';
%     rng(1000+run);
    templ = templateTree('Reproducible',true);

    % Step 3: 拆分训练测试集（可调 HoldOut 比例）这个比例是指测试集，越小越好…0.3就不错
    cv = cvpartition(size(X,1), 'HoldOut', 0.2);
    X_train = X(training(cv), :);
    y_train = y(training(cv), :);
    X_test  = X(test(cv), :);
    y_test  = y(test(cv), :);
    %
    % Step 4: 拟合回归模型（树集成，稳定解释强）
%         mdl = fitrensemble(X, y, ...
%             'Method', 'Bag', ...
%             'NumLearningCycles', 100, ...
%             'Learners', 'tree');

    % 正式训练
    %         mdl = fitrensemble(X_train, y_train, ...

    mdl = fitrensemble(X, y, ...
        'Method','LSBoost', ...
        'Learners', 'tree',...
        'OptimizeHyperparameters', {'NumLearningCycles','LearnRate','MinLeafSize','MaxNumSplits'}, ...
        'HyperparameterOptimizationOptions', struct( ...
        'KFold', 5, ...                         % CV 做在调参里
        'AcquisitionFunctionName','expected-improvement-plus', ...
        'MaxObjectiveEvaluations', 50, ...      % 可 40–80 视数据量调
        'ShowPlots', false, ...
        'Verbose', 0, ...
        'UseParallel', true));

    model_filename = sprintf('eta_model_topo%d', t);  % 文件名如 eta_model_topo1.mat
    saveLearnerForCoder(mdl, model_filename);


    X_test=X;
    y_test=y;
    % Step 5: 模型评估
    y_pred = predict(mdl, X_test);

    % === 统一计算指标（替换你原来的三行） ===
    res  = y_test - y_pred;

    % 基础指标
    MAE  = mean(abs(res));
    RMSE = sqrt(mean(res.^2));
    R2   = 1 - sum(res.^2) / sum((y_test - mean(y_test)).^2);

    % 百分比误差（加鲁棒保护）
    eps0  = 1e-8;
    APE   = abs(res) ./ max(abs(y_test), eps0);                 % |e|/|y|
    MAPE  = mean(APE)*100;
    MdAPE = median(APE)*100;                                  % 中位数更抗离群
    WAPE  = (sum(abs(res)) / max(sum(abs(y_test)), eps0))*100;  % 加权版本更稳

    % 归一化RMSE（对“方差很窄”更稳）
    sig_y = std(y_test, 1);           % 总体标准差
    IQRy  = iqr(y_test);              % 四分位距
    NRMSE_sigma = RMSE / max(sig_y, eps);
    NRMSE_IQR   = RMSE / max(IQRy,  eps);

    % —— 按 μ 分位分箱的宏平均 R²（避免被某个窄段主导）
    % 需要“原始μ（未zscore）”的测试集值：
    if exist('cv','var') && ~isempty(cv)
        mu_raw_test = X(test(cv), 1);     % Hold-Out 情况
    elseif exist('mu_raw_test','var')
        % 若已自备测试集的原始μ，就用它
    else
        error('请提供测试集的原始 μ（mu_raw_test）或使用 Hold-Out 的 cv。');
    end

    % 用分位数做自适应分箱，确保每箱都有样本
    edges = quantile(mu_raw_test, [0 0.2 0.4 0.6 0.8 1]);
    edges = unique(edges,'stable');                    % 防重复边界
    bin   = discretize(mu_raw_test, edges);

    r2_bins = nan(max(bin),1);
    for b = 1:max(bin)
        idx = (bin==b);
        if nnz(idx) >= 5 && std(y_test(idx)) > 0
            ss_res = sum((y_test(idx) - y_pred(idx)).^2);
            ss_tot = sum((y_test(idx) - mean(y_test(idx))).^2);
            r2_bins(b) = 1 - ss_res/ss_tot;
        end
    end
    R2_macro_mu = mean(r2_bins, 'omitnan');

    % —— 打印汇总
    fprintf(['MAE=%.4f  RMSE=%.4f  R^2=%.4f  MAPE=%.2f\n WAPE=%.2f\n'], MAE, RMSE, R2, MAPE, WAPE);

    % Step 6: 可视化预测结果
    %     figure;
    %     scatter(y_test, y_pred, 50, 'filled'); grid on;
    %     xlabel('True Efficiency'); ylabel('Predicted Efficiency');
    %     title('四特征回归模型：预测 vs 实际');
    %     refline(1,0);
end
% end

%% 分段法
% for t=6
%     % ===== Step 1: 取4特征与标签（保持原口径） =====
%     X = features(:, 1:4);              % [mu, rho, Dlow, hf]
%     y = yita(t,:)';
%     mu = X(:,1);                       % 场景均值(用于分段)
%     rng(2025);
%     templ = templateTree('Reproducible',true);
%
%     % ===== Step 3: Hold-Out 划分（保持你的0.7比例） =====
%     cv  = cvpartition(size(X,1), 'HoldOut', 0.8);
%     X_train = X(training(cv), :);   y_train = y(training(cv), :);
%     X_test  = X(test(cv), :);       y_test  = y(test(cv), :);
%     mu_tr   = X_train(:,1);         mu_te   = X_test(:,1);
%
%     % ===== Step 4A: 在训练集上“按 μ 单阈值”选择最佳切点（3折CV） =====
%     % 阈值候选：用训练集分位点更稳；避免段太小
%     thrGrid = unique(quantile(mu_tr, 0.30:0.05:0.70));
%     if numel(thrGrid)<2
%         a = min(mu_tr); b = max(mu_tr);
%         thrGrid = linspace(a + 1e-6, b - 1e-6, 4);
%     end
%     Nmin = 40;                          % 每段最少样本
%     Cinner = cvpartition(numel(y_train),'KFold',3);
%
%     best_thr = thrGrid(1);
%     best_mse = Inf;
%     for thr = thrGrid(:)'
%         ok_all = true;
%         mse_fold = zeros(Cinner.NumTestSets,1);
%         for k = 1:Cinner.NumTestSets
%             tri = training(Cinner,k);  vai = test(Cinner,k);
%             % 该折训练子集
%             Xtr_k = X_train(tri,:);  ytr_k = y_train(tri);  mu_k = mu_tr(tri);
%             Xva_k = X_train(vai,:);  yva_k = y_train(vai);  mu_v = mu_tr(vai);
%
%             % 两段样本量检查
%             idxL = (mu_k < thr); idxH = ~idxL;
%             if nnz(idxL) < Nmin || nnz(idxH) < Nmin
%                 ok_all = false; break;
%             end
%
%             % 两段分别训练（强默认，速度稳妥；不做HPO以免太慢）
%             mdlL_k = fitrensemble(Xtr_k(idxL,:), ytr_k(idxL), 'Method','LSBoost','Learners',templ, ...
%                 'NumLearningCycles',1500,'LearnRate',0.03,'MinLeafSize',60,'MaxNumSplits',300, ...
%                 'Verbose',0);
%             mdlH_k = fitrensemble(Xtr_k(idxH,:), ytr_k(idxH), 'Method','LSBoost','Learners',templ, ...
%                 'NumLearningCycles',1500,'LearnRate',0.03,'MinLeafSize',60,'MaxNumSplits',300, ...
%                 'Verbose',0);
%
%             % 验证集按阈值选择模型预测
%             yhat_k = zeros(size(yva_k));
%             iiL = (mu_v < thr); iiH = ~iiL;
%             if any(iiL), yhat_k(iiL) = predict(mdlL_k, Xva_k(iiL,:)); end
%             if any(iiH), yhat_k(iiH) = predict(mdlH_k, Xva_k(iiH,:)); end
%             mse_fold(k) = mean((yva_k - yhat_k).^2);
%         end
%         if ok_all
%             mse_cv = mean(mse_fold);
%             if mse_cv < best_mse
%                 best_mse = mse_cv; best_thr = thr;
%             end
%         end
%     end
%     fprintf('Topo %d | 选中阈值 thr=%.3f\n', t, best_thr);
%
%     % ===== Step 4B: 用最佳阈值在“整个训练集”上重训两段模型（可HPO） =====
%     % 这里保留你的贝叶斯调参，但在每段各跑一次
%     best_thr=0.2;
%     idxL_tr = (mu_tr < best_thr);  idxH_tr = ~idxL_tr;
%
%     % —— 左段（低μ）
%     mdlL = fitrensemble(X_train(idxL_tr,:), y_train(idxL_tr), ...
%         'Method','LSBoost', 'Learners', templ, ...
%         'OptimizeHyperparameters', {'NumLearningCycles','LearnRate','MinLeafSize','MaxNumSplits'}, ...
%         'HyperparameterOptimizationOptions', struct( ...
%         'KFold', 5, 'Repartition', true, ...
%         'AcquisitionFunctionName','expected-improvement-plus', ...
%         'MaxObjectiveEvaluations', 50, ...
%         'ShowPlots', false, 'Verbose', 0, 'UseParallel', true));
%
%     % —— 右段（高μ）
%     mdlH = fitrensemble(X_train(idxH_tr,:), y_train(idxH_tr), ...
%         'Method','LSBoost', 'Learners', templ, ...
%         'OptimizeHyperparameters', {'NumLearningCycles','LearnRate','MinLeafSize','MaxNumSplits'}, ...
%         'HyperparameterOptimizationOptions', struct( ...
%         'KFold', 5, 'Repartition', true, ...
%         'AcquisitionFunctionName','expected-improvement-plus', ...
%         'MaxObjectiveEvaluations', 50, ...
%         'ShowPlots', false, 'Verbose', 0, 'UseParallel', true));
%
%     % ===== Step 5: 测试集预测与指标（你的评估口径保持不变） =====
%     y_pred = zeros(size(y_test));
%     iiL_te = (mu_te < best_thr); iiH_te = ~iiL_te;
%     if any(iiL_te), y_pred(iiL_te) = predict(mdlL, X_test(iiL_te,:)); end
%     if any(iiH_te), y_pred(iiH_te) = predict(mdlH, X_test(iiH_te,:)); end
%     y_pred = min(max(y_pred,0),1);   % 物理边界裁剪
%
%     res  = y_test - y_pred;
%
%     % 基础指标
%     MAE  = mean(abs(res));
%     RMSE = sqrt(mean(res.^2));
%     R2   = 1 - sum(res.^2) / sum((y_test - mean(y_test)).^2);
%
%     % 百分比/归一化指标
%     eps0  = 1e-8;
%     APE   = abs(res) ./ max(abs(y_test), eps0);
%     MAPE  = mean(APE)*100;
%     WAPE  = (sum(abs(res)) / max(sum(abs(y_test)), eps0))*100;
%
%     sig_y = std(y_test, 1);  IQRy  = iqr(y_test);
%     NRMSE_sigma = RMSE / max(sig_y, eps);
%     NRMSE_IQR   = RMSE / max(IQRy,  eps);
%
%     % 按 μ 分位分箱的宏平均 R²
%     mu_raw_test = X(test(cv), 1);
%     edges = quantile(mu_raw_test, [0 0.2 0.4 0.6 0.8 1]);
%     edges = unique(edges,'stable');
%     bin   = discretize(mu_raw_test, edges);
%     r2_bins = nan(max(bin),1);
%     for b = 1:max(bin)
%         idx = (bin==b);
%         if nnz(idx) >= 5 && std(y_test(idx)) > 0
%             ss_res = sum((y_test(idx) - y_pred(idx)).^2);
%             ss_tot = sum((y_test(idx) - mean(y_test(idx))).^2);
%             r2_bins(b) = 1 - ss_res/ss_tot;
%         end
%     end
%     R2_macro_mu = mean(r2_bins, 'omitnan');
%
%     fprintf(['Topo %d | MAE=%.4f  RMSE=%.4f  R^2=%.4f  MAPE=%.2f  WAPE=%.2f  ' ...
%         'NRMSE(σ)=%.3f NRMSE(IQR)=%.3f  R^2_macro(μ)=%.4f\n'], ...
%         t, MAE, RMSE, R2, MAPE, WAPE, NRMSE_sigma, NRMSE_IQR, R2_macro_mu);
%
%     % ===== Step 6: 保存（两段模型+阈值）；如需 codegen，也分别保存左右段 =====
%     pack.kind = 'LSBoost-2segment-by-mu';
%     pack.thr  = best_thr;
%     pack.mdlL = compact(mdlL);
%     pack.mdlH = compact(mdlH);
%     save(sprintf('eta_model_topo%d_muSplit.mat', t), 'pack');
%
%     % 若需要 codegen 兼容（各存一份）
%     saveLearnerForCoder(compact(mdlL), sprintf('eta_model_topo%d_L', t));
%     saveLearnerForCoder(compact(mdlH), sprintf('eta_model_topo%d_H', t));
% end

