% 计算厂站在不同scheduling策略下每个module不同拓扑下的制氢量
project_data=readmatrix('ProjectInfo.xlsx', 'Sheet', 'Sheet1', 'Range', 'G2:O37');
num_project=length(project_data);
P_command=readmatrix('Project profiles.xlsx', 'Sheet', 'WS24', 'Range', 'C1:LXZ24');

% 技术经济参数
delta_t = 0.25; % 系统总电功率指令的时间颗粒度（单位：时）
capex_ratio=[1 10];
opex_ratio=[1 4];

capex=[2800 2738 2688 2662 2488 2272]*1e4;
opex=0.03;
lifetime=15;
cr=0.07;
ann_capex=capex*(opex+1/(1/cr-1/cr/(1+cr)^lifetime));

num=[4 4 4 2 2 1];

label=zeros(24,8);

for s=1:24 % num_project
    if project_data(s,4)==1
        price_ele = project_data(s,5)*7; % 电价（单位：元/kWh）
    elseif project_data(s,4)==2
        price_ele = project_data(s,6)*7*(opex+1/(1/cr-1/cr/(1+cr)^20))/project_data(s,8); % 电价（单位：元/kWh）
    else
        price_ele = project_data(s,7)*7*(opex+1/(1/cr-1/cr/(1+cr)^20))/project_data(s,9); % 电价（单位：元/kWh）
    end
    price_H2 = price_ele*60/11.2; % 氢价（单位：元/Nm3）

    for N_module=10 %20:20:100 % 表征厂站规模

        % 计算总指令
        P_total = reshape((P_command(s,:)) *20 * N_module, [24,365])';  % 示例：365×24，总功率曲线（单位 MW）
        profit_plant=[];
        profit_bench=[];

        for base=0:0.1:1 % 0等价于equalsplit，1等价于scheduling
            cal_smart;
            [num_days, num_modules, num_features] = size(features_test);

            file_name = sprintf('result_WS24_%d.xlsx', s);
            sheet_name = sprintf('N%d_Base%d', N_module, floor(base*20));
            range = sprintf('A%d', 1);

            % 计算目标函数
            obj=zeros(6,num_modules); % 每种调度策略下每种拓扑在每个点位的成本
            profit_base_module=zeros(length(capex_ratio)*length(opex_ratio),num_modules); % 每种调度策略下每个点位最优拓扑的净利润
            opt_base_module=zeros(length(capex_ratio)*length(opex_ratio),num_modules); % 每种调度策略下每个点位最优拓扑编号
            profit_base_plant=zeros(length(capex_ratio)*length(opex_ratio),1); % 每种调度策略下不同成本边界下厂站最优利润
            production_base_plant=zeros(length(capex_ratio)*length(opex_ratio),1); % 每种调度策略下最优拓扑方案下的实际产氢量
            profit_base_benchmark=zeros(length(capex_ratio)*length(opex_ratio),1); % 每种调度策略下T1对应厂站利润

            for cr=1:length(capex_ratio)
                for or=1:length(opex_ratio)
                    for t=1:6
                        for m=1:num_modules % 1
                            obj(t,m)=production(t,m)*11.2*1000*price_H2*opex_ratio(or)-sum(sum(P_module(:, :, m)))*1000*price_ele/4-ann_capex(t)*capex_ratio(cr);
                        end
                    end
                    if base==0
                        module_5(or+length(opex_ratio)*(cr-1),:)=[production(1,1)/4 obj(1,1)/4]; % 5MW标准件的产量和利润
                        module_10(or+length(opex_ratio)*(cr-1),:)=[production(4,1)/2 obj(4,1)/2]; % 10MW标准件的产量和利润
                        profit_bench(or+length(opex_ratio)*(cr-1),1)=sum(obj(1,:));
                    end
                    [profit_base_module(or+length(opex_ratio)*(cr-1),:), opt_base_module(or+length(opex_ratio)*(cr-1),:)]=max(obj);
                    profit_base_plant(or+length(opex_ratio)*(cr-1),1)=sum(profit_base_module(or+length(opex_ratio)*(cr-1),:));
                    profit_base_benchmark(or+length(opex_ratio)*(cr-1),1)=sum(obj(1,:));
                    production_base_plant(or+length(opex_ratio)*(cr-1),1)=sum(production(sub2ind(size(production), opt_base_module(or+length(opex_ratio)*(cr-1),:), (1:num_modules))));
                end
            end
            profit_plant=[profit_plant profit_base_plant]; % 所有调度策略下不同成本边界下厂站最优利润
            writematrix([production sum(production,2) sum(production,2) sum(production,2);opt_base_module production_base_plant profit_base_plant profit_base_benchmark], file_name, 'Sheet', sheet_name, 'Range', range);


        end

        [~, opt_base]=max(profit_plant');
        plant_sum=[]; % 不同成本边界下厂站最优调度+拓扑+产量+利润结果
        for cr=1:length(capex_ratio)
            for or=1:length(opex_ratio)
                sheet_name = sprintf('N%d_Base%d', N_module, 2*(opt_base(or+length(opex_ratio)*(cr-1))-1));
                range = sprintf('A%d', 6+or+length(opex_ratio)*(cr-1));
                data=readmatrix(file_name, 'Sheet', sheet_name, 'Range', range);
                data_topo=data(1,1:num_modules);
                counts = histcounts(data_topo, 1:7)/num_modules; % 统计1~6的频次（注意区间右边界为7）
                plant_sum=[plant_sum; 2*(opt_base(or+length(opex_ratio)*(cr-1))-1) counts data(1,1:end-1)];
            end
        end
        sheet_name = sprintf('N%d', N_module);
        range = sprintf('A%d', 1);
        writematrix([plant_sum profit_bench (plant_sum(:,end)-profit_bench)./profit_bench], file_name, 'Sheet', sheet_name, 'Range', range);

        real_modules(s)=num_modules;

    end
    label(s,1:4)=plant_sum(:,1)'/P_base;
    label(s,5:8)=(plant_sum(:,2:7)*[0;1;2;3;4;5]/5)';
    label(s,9:12)=((plant_sum(:,end)-profit_bench)./profit_bench)';
end