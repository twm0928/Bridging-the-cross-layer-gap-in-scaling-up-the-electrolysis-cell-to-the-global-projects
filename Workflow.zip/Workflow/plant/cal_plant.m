% 计算厂站在不同scheduling策略下每个module不同拓扑下的制氢量

% 技术经济参数
delta_t = 0.25; % 系统总电功率指令的时间颗粒度（单位：时）
capex_ratio=[0.5 1 2 4];
opex_ratio=[1 2 4];

capex=[2800 2738 2688 2662 2488 2272]*1e4;
opex=0.03;
lifetime=15;
cr=0.07;
ann_capex=capex*(opex+1/(1/cr-1/cr/(1+cr)^lifetime));

price_ele = 0.2; % 电价（单位：元/kWh）
price_H2 = price_ele*60/11.2; % 氢价（单位：元/Nm3）
num=[4 4 4 2 2 1];

% 指令参数
load('P_command.mat');
% sum(sum(P_command(366:730, :)))
num_points = size(P_command,2);

% cal_fitting; % 基于240生成场景计算拟合函数，不需要重复计算

for s=1:2
    for N_module=20 %20:20:100 % 表征厂站规模

        % 计算总指令
        P_total = (P_command(1+365*(s-1):365*s, :)) * N_module;  % 示例：365×24，总功率曲线（单位 MW）
%         profit_plant=[];

        for base=0:0.1:1 % 0等价于equalsplit，1等价于scheduling

            % 计算不同策略下每个点位指令时序曲线及其特征参数P_module(d, h, m)，features_test(d, m, 4)
            cal_smart;

            [num_days, num_modules, num_features] = size(features_test);
            features_mean = squeeze(mean(features_test, 1));
%             if s==1
%                 marker_type='o';
%             else
%                 marker_type='s';
%             end
%             scatter(features_mean(:,1), features_mean(:,3), 100, colors(strategy,:), marker_type, 'filled');
%             xlabel('Mean Power (%)');
%             ylabel('Mean Ramping (/15min)');
%             hold on;
%             for i = 1:length(features_mean)
%                 text(features_mean(i,1), features_mean(i,3), sprintf('%d', i), ...
%                     'VerticalAlignment', 'middle', ...
%                     'HorizontalAlignment', 'center', ...
%                     'FontSize', 8, ...
%                     'Color', 'k');  % 黑色文本
%             end
%             strategy=strategy+1;
%         end
%         axis([0 1 0 0.05]);
%         legend('Strategy base0', 'Strategy base20', 'Strategy base40', 'Strategy base60', 'Strategy base80', 'Strategy base100', 'Location', 'best');

% % % % %             tic
% % % % %             production=zeros(6, num_modules); % 每种拓扑在每个点位的年度累积制氢量，t
% % % % %             parfor t=1:6
% % % % %                 for m=1:num_modules % 1
% % % % %                     for d=1:days
% % % % %                         model_filename = sprintf('eta_model_topo%d', t);  % 文件名如 eta_model_topo1.mat
% % % % %                         mdl = loadLearnerForCoder(model_filename);
% % % % %                         yita = predict(mdl, reshape(features_test(d, m, :), 1, 4));
% % % % %                         production(t, m)=production(t, m)+yita*sum(P_module(d, :, m))/33.33/4;
% % % % %                     end
% % % % %                 end
% % % % %             end
% % % % %             toc                      
% % % % %             
% % % % %             file_name = sprintf('result%d.xlsx', s);
% % % % %             sheet_name = sprintf('N%d_Base%d', N_module, floor(P_base/1));
% % % % %             range = sprintf('A%d', 1);
% % % % % %             data=readmatrix(file_name, 'Sheet', sheet_name, 'Range', range);
% % % % % %             production=data(1:6,1:num_modules);
% % % % % 
% % % % %             % 计算目标函数
% % % % %             obj=zeros(6,num_modules); % 每种调度策略下每种拓扑在每个点位的成本
% % % % %             profit_base_module=zeros(length(capex_ratio)*length(opex_ratio),num_modules); % 每种调度策略下每个点位最优拓扑的净利润
% % % % %             opt_base_module=zeros(length(capex_ratio)*length(opex_ratio),num_modules); % 每种调度策略下每个点位最优拓扑编号
% % % % %             profit_base_plant=zeros(length(capex_ratio)*length(opex_ratio),1); % 每种调度策略下不同成本边界下厂站最优利润
% % % % %             production_base_plant=zeros(length(capex_ratio)*length(opex_ratio),1); % 每种调度策略下最优拓扑方案下的实际产氢量
% % % % %             profit_base_benchmark=zeros(length(capex_ratio)*length(opex_ratio),1); % 每种调度策略下T1对应厂站利润
% % % % % 
% % % % %             for cr=1:length(capex_ratio)
% % % % %                 for or=1:length(opex_ratio)
% % % % %                     for t=1:6
% % % % %                         for m=1:num_modules % 1
% % % % %                             obj(t,m)=production(t,m)*11.2*1000*price_H2*opex_ratio(or)-sum(sum(P_module(:, :, m)))*1000*price_ele/4-ann_capex(t)*capex_ratio(cr);
% % % % %                         end
% % % % %                     end
% % % % %                     [profit_base_module(or+length(opex_ratio)*(cr-1),:), opt_base_module(or+length(opex_ratio)*(cr-1),:)]=max(obj);
% % % % %                     profit_base_plant(or+length(opex_ratio)*(cr-1),1)=sum(profit_base_module(or+length(opex_ratio)*(cr-1),:));
% % % % %                     profit_base_benchmark(or+length(opex_ratio)*(cr-1),1)=sum(obj(1,:));
% % % % %                     production_base_plant(or+length(opex_ratio)*(cr-1),1)=sum(production(sub2ind(size(production), opt_base_module(or+length(opex_ratio)*(cr-1),:), (1:num_modules))));
% % % % %                 end
% % % % %             end
% % % % %             profit_plant=[profit_plant profit_base_plant]; % 所有调度策略下不同成本边界下厂站最优利润
% % % % %             writematrix([production sum(production,2) sum(production,2) sum(production,2);opt_base_module production_base_plant profit_base_plant profit_base_benchmark], file_name, 'Sheet', sheet_name, 'Range', range);
% % % % % %             writematrix(features_mean, 'features1.xlsx', 'Sheet', sheet_name, 'Range', range);

        end

%         [~, opt_base]=max(profit_plant');
%         plant_sum=[]; % 不同成本边界下厂站最优调度+拓扑+产量+利润结果
%         for cr=1:length(capex_ratio)
%             for or=1:length(opex_ratio)
%                 sheet_name = sprintf('N%d_Base%d', N_module, 2*(opt_base(or+length(opex_ratio)*(cr-1))-1));
%                 range = sprintf('A%d', 6+or+length(opex_ratio)*(cr-1));
%                 data=readmatrix(file_name, 'Sheet', sheet_name, 'Range', range);
%                 data_topo=data(1,1:num_modules);
%                 counts = histcounts(data_topo, 1:7)/num_modules; % 统计1~6的频次（注意区间右边界为7）
%                 plant_sum=[plant_sum; 2*(opt_base(or+length(opex_ratio)*(cr-1))-1) counts data(1,1:end-1)];
%             end
%         end
%         sheet_name = sprintf('N%d', N_module);
%         range = sprintf('A%d', 1);
%         writematrix(plant_sum, file_name, 'Sheet', sheet_name, 'Range', range);
    end
end