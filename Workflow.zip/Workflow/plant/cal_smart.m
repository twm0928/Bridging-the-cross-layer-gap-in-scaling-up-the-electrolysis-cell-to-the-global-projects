% N_module = 10;                 % 模块数量
P_module_max = 20;             % 每个模块最大功率（MW）
P_base = base*P_module_max;
N_real_module = ceil(max(max(P_total))/P_module_max);

[days, hours] = size(P_total);
P_module = zeros(days, hours, N_real_module);  % 初始化模块分配矩阵
features_test = zeros(days, N_real_module, 4);
num_points = hours;

for d = 1:days
    for h = 1:hours
        remaining = P_total(d, h);

        % Step 1: 初始预分配 P_base
        P_module(d, h, :) = 0;
        for m = 1:N_real_module
            if remaining >= P_base
                P_module(d, h, m) = P_base;
                remaining = remaining - P_base;
            else
                P_module(d, h, m) = remaining;
                remaining = 0;
                break;
            end
        end

        % Step 2: 等分剩余功率（先检查有无剩余）
        if remaining > 0
            % 可增加量 = 每个模块的剩余能力
            room = P_module_max - P_module(d, h, :);
            room = max(room, 0);  % 防止负值
            total_room = sum(room);

            if total_room > 0
                % 按容量空余比例分配剩余功率
                ratio = room / total_room;
                P_module(d, h, :) = P_module(d, h, :) + remaining * ratio;
            end
        end
    end
end

for d = 1:days
    for m = 1:N_real_module

        x = P_module(d, :, m);

        % 特征1：mean_val（平均功率,MW）
        features_test(d, m, 1) = mean(x)/20;

        % 特征2：low_hold_duration（低负荷最大连续时长,15min）
        threshold = 0.2 * 20;
        below_thresh = x < threshold;
        max_len = 0; current_len = 0;
        for j = 1:num_points
            if below_thresh(j)
                current_len = current_len + 1;
                max_len = max(max_len, current_len);
            else
                current_len = 0;
            end
        end
        features_test(d, m, 2) = max_len/96;

        % 特征3：freq_delta（相邻差值平均,%/15min）
        dx = diff(x);
        features_test(d, m, 3) = mean(abs(dx))/20;

        % 特征4：fft_high_ratio（周期≤1小时的高频能量占比）
        X = abs(fft(x));
        X = X(2:floor(num_points/2));  % 去掉直流项和对称部分
        fs = 4;                        % 每小时4个采样点
        freq_resolution = fs / num_points;
        freqs = (1:length(X)) * freq_resolution;  % 各频率点（单位：次/小时）

        high_freq_idx = freqs >= 1;  % 高频频率索引（周期≤1小时）
        features_test(d, m, 4) = sum(X(high_freq_idx)) / sum(X);

    end
end

features_test(find(isnan(features_test)==1)) = 0;